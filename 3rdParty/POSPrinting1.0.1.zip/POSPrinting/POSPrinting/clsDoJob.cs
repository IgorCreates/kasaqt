﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Printing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace POSPrinting
{
    public class clsDoJob
    {
        private clsPrintSettings cPrintSettings;
        public clsDoJob(clsPrintSettings p)
        {
            cPrintSettings = p;
        }

        public bool Run()
        {
            string errorMessage;
            if (cPrintSettings.IsDataValid(out errorMessage))
            {
                if (cPrintSettings.bPrintFileToPrinter)
                    this.PrintData();
                if (cPrintSettings.bChangeAndRewriteFileEncoding)
                    this.ChangeFileEncoding();
            }
            else
            {
                MessageBox.Show("Unesene postavke nisu ispravne: " + errorMessage, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return true;
        }

        private bool PrintData()
        {
            PrintDocument p = new PrintDocument();
            try
            {
                if (cPrintSettings.PrinterName.Length > 0)
                    p.PrinterSettings.PrinterName = cPrintSettings.PrinterName;
            }
            catch(Exception ex)
            {
                //do nothing
            }

            ///Ucitavanje datoteke
            string textForPrint=""; 
            bool bFileReaded = true;
            try
            {
                Encoding en;
                this.GetEncoding(cPrintSettings.InputTextEncoding, out en);
                // Read the file as one string.
                textForPrint = System.IO.File.ReadAllText(cPrintSettings.TextFilePath, en);
            }
            catch (Exception ex)
            {
                bFileReaded = false;
            }

            Point loc = new Point(0, 0);

            //"Andale Mono", "Courier New"
            //Font font = new Font("Consolas", 8);
            Font font = cPrintSettings.PrintFont;

            p.PrintPage += delegate(object sender1, PrintPageEventArgs e1)
            {
                int heightUsed = 0;
                ///Ucitavanje i ispis slike
                System.Drawing.Image imageHeader;
                if (cPrintSettings.bHeaderImageIsPrinting)
                {
                    try
                    {
                        //load image
                        imageHeader = Image.FromFile(cPrintSettings.HeaderImageFilePath);
                        //resize image
                        Size size = new System.Drawing.Size(cPrintSettings.HeaderImagePrintingWidth, cPrintSettings.HeaderImagePrintingHeight);
                        imageHeader = cPrintSettings.ResizeImage(imageHeader, size);
                        cPrintSettings.HeaderImagePrintingHeight = imageHeader.Height;
                        e1.Graphics.DrawImage(imageHeader, loc);
                        heightUsed = imageHeader.Height;
                    }
                    catch (Exception ex)
                    {
                        imageHeader = null;
                    }
                }
                if (bFileReaded)
                    e1.Graphics.DrawString(textForPrint, font, new SolidBrush(Color.Black), new RectangleF(0, heightUsed, p.DefaultPageSettings.PrintableArea.Width, p.DefaultPageSettings.PrintableArea.Height));
                else
                    e1.Graphics.DrawString("Nepostojeća datoteka: " + cPrintSettings.TextFilePath, font, new SolidBrush(Color.Black), new RectangleF(0, heightUsed, p.DefaultPageSettings.PrintableArea.Width, p.DefaultPageSettings.PrintableArea.Height));
            };
            try
            {
                p.Print();
                return true;
            }
            catch (Exception ex)
            {
                //throw new Exception("Exception Occured While Printing", ex);
                return false;
            }
        }

        private bool ChangeFileEncoding()
        {
            try
            {
                Encoding ecIN, ecOUT;
                this.GetEncoding(cPrintSettings.InputTextEncoding, out ecIN);
                this.GetEncoding(cPrintSettings.OutputTextEncoding, out ecOUT);

                string text = System.IO.File.ReadAllText(cPrintSettings.TextFilePath, ecIN);
                System.IO.File.WriteAllText(cPrintSettings.TextFilePath, text, ecOUT);
            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Dohvat kodne stranice na osnovu oznake kodne stranice
        /// </summary>
        /// <param name="strCodePage"></param>
        /// <param name="ec"></param>
        /// <returns></returns>
        private bool GetEncoding(string strCodePage, out Encoding ec)
        {
            try
            {
                int nCodePage;
                if (strCodePage.Length > 0)
                {
                    if (int.TryParse(strCodePage, out nCodePage))
                        ec = Encoding.GetEncoding(nCodePage);
                    else
                        ec = Encoding.GetEncoding(strCodePage);
                }
                else
                {
                    ec = Encoding.Default;
                }
            }
            catch (Exception ex)
            {
                ec = Encoding.Default;
                return false;
            }
            return true;
        }
    }
}
