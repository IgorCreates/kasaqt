﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace POSPrinting
{
    public class clsPrintSettings
    {
        /// <summary>
        /// Izabrani printer za printanje
        /// </summary>
        private string _printerName;
        /// <summary>
        /// da li se printa slika na vrhu
        /// </summary>
        private bool _headerImageIsPrinting;
        /// <summary>
        /// Lokacija slike koja se ispisuje
        /// </summary>
        private string _headerImageFilePath;
        /// <summary>
        /// Visina header slike
        /// </summary>
        private int _headerImageHeight;
        /// <summary>
        /// Sirina header slike
        /// </summary>        
        private int _headerImageWidth;
        /// <summary>
        /// Lokacija tekstualne datoteke koja se ispisuje
        /// </summary>
        private string _textFilePath;
        /// <summary>
        /// Kodna stranica ulazne datoteke
        /// </summary>
        private string _inputTextEncoding;
        /// <summary>
        /// Kodna stranica izlazne datoteke
        /// </summary>
        private string _outputTextEncoding;
        /// <summary>
        /// Promijeniti encoding ulayne datoteke
        /// </summary>
        private bool _bChangeAndRewriteFileEncoding;
        /// <summary>
        /// Ispis ulazne datoteke
        /// </summary>
        private bool _bPrintFileToPrinter;

        private Font _printFont;

        /// <summary>
        /// Default constructor
        /// </summary>
        public clsPrintSettings()
        {
            this._printerName = "";
            this._headerImageIsPrinting = false;
            this._headerImageFilePath = "";
            this._headerImageHeight = 0;
            this._headerImageWidth = 0;
            this._textFilePath = "";
            this._inputTextEncoding = "";
            this._outputTextEncoding = "";
            this._bChangeAndRewriteFileEncoding = false;
            this._bPrintFileToPrinter = false;
            this._printFont = new Font("Consolas", 8);
        }
        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="p">class source data</param>
        public clsPrintSettings(clsPrintSettings p)
        {
            this._printerName = p.PrinterName;
            this._headerImageIsPrinting = p.bHeaderImageIsPrinting;
            this._headerImageFilePath = p.HeaderImageFilePath;
            this._headerImageHeight = p.HeaderImagePrintingHeight;
            this._headerImageWidth = p.HeaderImagePrintingWidth;
            this._textFilePath = p.TextFilePath;
            this._inputTextEncoding = p.InputTextEncoding;
            this._outputTextEncoding = p.OutputTextEncoding;
            this._bChangeAndRewriteFileEncoding = p.bChangeAndRewriteFileEncoding;
            this._bPrintFileToPrinter = p.bPrintFileToPrinter;
            this._printFont = p.PrintFont;
        }

        public bool IsDataValid(out string errorMessage)
        {
            bool bDataAreValid = true;
            errorMessage = "";

            if (!System.IO.File.Exists(this.TextFilePath))
            {
                errorMessage = errorMessage + "Datoteka " + this.TextFilePath + " ne postoji." + "\n";
                bDataAreValid = false;
            }
            if (this.InputTextEncoding.Length > 0)
                if (!this.ValidateEncoding(this.InputTextEncoding))
                {
                    errorMessage = errorMessage + "Kodna stranica " + this.InputTextEncoding + " nije ispravna." + "\n";
                    bDataAreValid = false;
                }

            //provjera ako se file printa
            if (this.bPrintFileToPrinter)
            {
                if (!this.ValidatePrinterName(this.PrinterName))
                {
                    errorMessage = errorMessage + "Printer " + this.PrinterName + " ne postoji." + "\n";
                    bDataAreValid = false;
                }
            }
            
            //provjera za encoding promjenu datoteke
            if (this.bChangeAndRewriteFileEncoding)
            {
                if (this.OutputTextEncoding.Length > 0)
                    if (!this.ValidateEncoding(this.OutputTextEncoding))
                    {
                        errorMessage = errorMessage + "Kodna stranica " + this.OutputTextEncoding + " nije ispravna." + "\n";
                        bDataAreValid = false;
                    }
            }

            //da li je yadan i jedan posao
            if (!this.bPrintFileToPrinter && !this.bChangeAndRewriteFileEncoding)
            {
                errorMessage = errorMessage + "Niste zadali posao: 1. Printanje, 2. Change file encoding, 3 Oboje navedeno (1 i 2) " + "\n";
                bDataAreValid = false;
            }

            //provjera grafike
            if (this.bHeaderImageIsPrinting)
            {
                if (!System.IO.File.Exists(this.HeaderImageFilePath))
                {
                    errorMessage = errorMessage + "Datoteka " + this.HeaderImageFilePath + " ne postoji." + "\n";
                    bDataAreValid = false;
                }
                if (this.HeaderImagePrintingHeight < 1)
                {
                    errorMessage = errorMessage + "Visina slike " + this.HeaderImagePrintingHeight.ToString() + " nije ispravna." + "\n";
                    bDataAreValid = false;
                }
                if (this.HeaderImagePrintingWidth < 1)
                {
                    errorMessage = errorMessage + "Širina slike " + this.HeaderImagePrintingWidth.ToString() + " nije ispravna." + "\n";
                    bDataAreValid = false;
                }
            }

            return bDataAreValid;
        }

        /// <summary>
        /// Provjera da li je kodna stranica ispravna
        /// </summary>
        /// <param name="codePage">oznaka kodne stranice (prazan string = Encoding.Default)</param>
        /// <returns>true - kodna stranica OK|false - nepodržana kodna stranica</returns>
        public bool ValidateEncoding(string strCodePage)
        {
            try
            {
                int nCodePage;
                Encoding ec;
                if (strCodePage.Length > 0)
                {
                    if (int.TryParse(strCodePage, out nCodePage))
                        ec = Encoding.GetEncoding(nCodePage);
                    else
                        ec = Encoding.GetEncoding(strCodePage);
                }
                else
                {
                    ec = Encoding.Default;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// Provjera da li printer postoji
        /// </summary>
        /// <param name="codePage">naziv printera</param>
        /// <returns>true - printer postoji|false - printer ne postoji</returns>
        public bool ValidatePrinterName(string printerName)
        {
            //provjera printera
            System.Windows.Forms.PrintDialog dlg = new System.Windows.Forms.PrintDialog();
            dlg.PrinterSettings.PrinterName = printerName;
            return dlg.PrinterSettings.IsValid;
        }

        public Image ResizeImage(Image imgToResize, Size size)
        {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;

            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;

            nPercentW = ((float)size.Width / (float)sourceWidth);
            nPercentH = ((float)size.Height / (float)sourceHeight);

            if (nPercentH < nPercentW)
                nPercent = nPercentH;
            else
                nPercent = nPercentW;

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((Image)b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();

            return (Image)b;
        }

        /// <summary>
        /// Naziv printera
        /// </summary>
        public string PrinterName
        {
            get { return _printerName; }
            set
            {
                _printerName = value;
            }
        }
        /// <summary>
        /// Da li se ispisuje slika na vrhu
        /// </summary>
        public bool bHeaderImageIsPrinting
        {
            get { return _headerImageIsPrinting; }
            set
            {
                _headerImageIsPrinting = value;
            }
        }
        /// <summary>
        /// Path do slike koja se ispisuje u headeru (puni ili relative)
        /// </summary>
        public string HeaderImageFilePath
        {
            get { return _headerImageFilePath; }
            set
            {
                _headerImageFilePath = value;
            }
        }
        /// <summary>
        /// Visina slike pri ispisu (u pointima)
        /// </summary>
        public int HeaderImagePrintingHeight
        {
            get { return _headerImageHeight; }
            set
            {
                _headerImageHeight = value;
            }
        }
        /// <summary>
        /// Sirina slike pri ispisu (u pointima)
        /// </summary>
        public int HeaderImagePrintingWidth
        {
            get { return _headerImageWidth; }
            set
            {
                _headerImageWidth = value;
            }
        }
        /// <summary>
        /// Path do tekstualne datoteke koja se ispisuje u headeru (puni ili relative)
        /// </summary>
        public string TextFilePath
        {
            get { return _textFilePath; }
            set
            {
                _textFilePath = value;
            }
        }
        /// <summary>
        /// Encoding page ulazne datoteke
        /// </summary>
        public string InputTextEncoding
        {
            get { return _inputTextEncoding; }
            set
            {
                _inputTextEncoding = value;
            }
        }
        /// <summary>
        /// Encoding page izlazne datoteke
        /// </summary>
        public string OutputTextEncoding
        {
            get { return _outputTextEncoding; }
            set
            {
                _outputTextEncoding = value;
            }
        }
        /// <summary>
        /// Da li napraviti promjenu kodne stranice ulazne datoteke
        /// </summary>
        public bool bChangeAndRewriteFileEncoding
        {
            get { return _bChangeAndRewriteFileEncoding; }
            set
            {
                _bChangeAndRewriteFileEncoding = value;
            }
        }
        /// <summary>
        /// Da li ispisati datoteku na printer
        /// </summary>
        public bool bPrintFileToPrinter
        {
            get { return _bPrintFileToPrinter; }
            set
            {
                _bPrintFileToPrinter = value;
            }
        }
        /// <summary>
        /// Font odabran za printanje
        /// </summary>
        public Font PrintFont
        {
            get { return _printFont; }
            set
            {
                _printFont = value;
            }
        }
    }
}
