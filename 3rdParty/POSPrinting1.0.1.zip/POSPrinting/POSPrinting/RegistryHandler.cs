﻿using System;
using System.Diagnostics;
using System.Collections;
using Microsoft.Win32;
using POSPrinting;

public class RegistryHandler
{
    private RegistryKey regBaseKey;
    private string strRegPath;
    private string _ApplicationName;
    string datumVrijemeFormat = "yyyy-MM-dd HH:mm:ss";

    /// <summary>
    /// Class constructor
    /// </summary>
    /// <param name="ApplicationName">Naziv aplikacije</param>
    /// <param name="RegistryRootPath">Osnovni registry path</param>
    public RegistryHandler(string ApplicationName, string RegistryRootPath)
    {
        this._ApplicationName = ApplicationName;
        //this.regBaseKey = Registry.LocalMachine;
        this.regBaseKey = Registry.CurrentUser;
        this.regPath = RegistryRootPath;
    }

    private string regPath
    {
        get
        {
            return strRegPath;
        }
        set
        {
            strRegPath = value;
        }
    }

    public bool WritePrinterSettings(clsPrintSettings printSettings)
    {
        RegistryKey rkPrintSettings;
        try
        {
            ///Osnovne postavke
            regBaseKey.CreateSubKey(regPath);
            rkPrintSettings = regBaseKey.OpenSubKey(regPath, true);
            rkPrintSettings.SetValue("PrinterName", printSettings.PrinterName, RegistryValueKind.String);
            rkPrintSettings.SetValue("FontName", printSettings.PrintFont.Name, RegistryValueKind.String);
            rkPrintSettings.SetValue("FontSize", printSettings.PrintFont.Size, RegistryValueKind.DWord);
            if (printSettings.PrintFont.Bold)
                rkPrintSettings.SetValue("FontBold", "1", RegistryValueKind.DWord);
            else
                rkPrintSettings.SetValue("FontBold", "0", RegistryValueKind.DWord);
            rkPrintSettings.Close();
            
            ///Postavke grafike (Image datoteke)
            regBaseKey.CreateSubKey(regPath + @"ImageHeader");
            rkPrintSettings = regBaseKey.OpenSubKey(regPath + @"ImageHeader", true);
            if (printSettings.bHeaderImageIsPrinting)
                rkPrintSettings.SetValue("HeaderImageIsPrinting", "1", RegistryValueKind.DWord);
            else
                rkPrintSettings.SetValue("HeaderImageIsPrinting", "0", RegistryValueKind.DWord);
            rkPrintSettings.SetValue("HeaderImageFilePath", printSettings.HeaderImageFilePath, RegistryValueKind.String);
            rkPrintSettings.SetValue("PrintingHeight", printSettings.HeaderImagePrintingHeight, RegistryValueKind.DWord);
            rkPrintSettings.SetValue("PrintingWidth", printSettings.HeaderImagePrintingWidth, RegistryValueKind.DWord);
            rkPrintSettings.Close();

            ///Postavke teksta (tekstualna datoteka)
            regBaseKey.CreateSubKey(regPath + @"TekstFile");
            rkPrintSettings = regBaseKey.OpenSubKey(regPath + @"TekstFile", true);
            if (printSettings.bPrintFileToPrinter)
                rkPrintSettings.SetValue("PrintFileToPrinter", "1", RegistryValueKind.DWord);
            else
                rkPrintSettings.SetValue("PrintFileToPrinter", "0", RegistryValueKind.DWord);
            if (printSettings.bChangeAndRewriteFileEncoding)
                rkPrintSettings.SetValue("ChangeAndRewriteFileEncoding", "1", RegistryValueKind.DWord);
            else
                rkPrintSettings.SetValue("ChangeAndRewriteFileEncoding", "0", RegistryValueKind.DWord);
            rkPrintSettings.SetValue("TextFilePath", printSettings.TextFilePath, RegistryValueKind.String);
            rkPrintSettings.SetValue("InputTextEncoding", printSettings.InputTextEncoding, RegistryValueKind.String);
            rkPrintSettings.SetValue("OutputTextEncoding", printSettings.OutputTextEncoding, RegistryValueKind.String);
            rkPrintSettings.Close();
            return true;
        }
        catch (Exception e)
        {
            //EventLog.WriteEntry(this._ApplicationName, "Error: WriteMailSettings" + e.ToString(), EventLogEntryType.Error);
            return false;
        }
    }

    public bool ReadData(out clsPrintSettings cPrintSettings)
    {
        RegistryKey rkSubkey;

        cPrintSettings= new clsPrintSettings();
        
        string value;
        int nvalue;
        /// Osnovne postavke
        rkSubkey = regBaseKey.OpenSubKey(regPath, RegistryKeyPermissionCheck.ReadWriteSubTree, System.Security.AccessControl.RegistryRights.FullControl);
        if (this.ReadSubKey(rkSubkey, "PrinterName", out value))
            cPrintSettings.PrinterName = value;
        else
            cPrintSettings.PrinterName ="";

        //Font
        if (this.ReadSubKey(rkSubkey, "FontName", out value))
        {
            string fontName = value;
            if (this.ReadSubKey(rkSubkey, "FontSize", out value))
            {
                if (int.TryParse(value, out nvalue))
                {
                    cPrintSettings.PrintFont = new System.Drawing.Font(fontName, nvalue);
                }
            }
        }


        if (rkSubkey != null) rkSubkey.Close();

        ///Postavke grafike (Image datoteke)
        rkSubkey = regBaseKey.OpenSubKey(regPath + @"\" +@"ImageHeader", RegistryKeyPermissionCheck.ReadWriteSubTree, System.Security.AccessControl.RegistryRights.FullControl);
        //HeaderImageIsPrinting
        this.ReadSubKey(rkSubkey, "HeaderImageIsPrinting", out value);
        cPrintSettings.bHeaderImageIsPrinting = value.Equals("1");
        //HeaderImageFilePath
        if (this.ReadSubKey(rkSubkey, "HeaderImageFilePath", out value))
            cPrintSettings.HeaderImageFilePath = value;
        else
            cPrintSettings.HeaderImageFilePath ="";
        //PrintingHeight
        if (this.ReadSubKey(rkSubkey, "PrintingHeight", out value))
        {
            if (int.TryParse(value, out nvalue))
                cPrintSettings.HeaderImagePrintingHeight = nvalue;
            else
                cPrintSettings.HeaderImagePrintingHeight = 0;
        }
        else
            cPrintSettings.HeaderImagePrintingHeight = 0;
        //PrintingWidth
        if (this.ReadSubKey(rkSubkey, "PrintingWidth", out value))
        {
            if (int.TryParse(value, out nvalue))
                cPrintSettings.HeaderImagePrintingWidth = nvalue;
            else
                cPrintSettings.HeaderImagePrintingWidth = 0;
        }
        else
            cPrintSettings.HeaderImagePrintingWidth = 0;
        if (rkSubkey != null) rkSubkey.Close();


        ///Postavke teksta (tekstualna datoteka)
        rkSubkey = regBaseKey.OpenSubKey(regPath + @"\" + @"TekstFile", RegistryKeyPermissionCheck.ReadWriteSubTree, System.Security.AccessControl.RegistryRights.FullControl);
        //HeaderImageIsPrinting
        this.ReadSubKey(rkSubkey, "PrintFileToPrinter", out value);
        cPrintSettings.bPrintFileToPrinter = value.Equals("1");
        //ChangeAndRewriteFileEncoding
        this.ReadSubKey(rkSubkey, "ChangeAndRewriteFileEncoding", out value);
        cPrintSettings.bChangeAndRewriteFileEncoding = value.Equals("1");
        //TextFilePath
        if (this.ReadSubKey(rkSubkey, "TextFilePath", out value))
            cPrintSettings.TextFilePath = value;
        else
            cPrintSettings.TextFilePath = "";
        //InputTextEncoding
        if (this.ReadSubKey(rkSubkey, "InputTextEncoding", out value))
            cPrintSettings.InputTextEncoding = value;
        else
            cPrintSettings.InputTextEncoding = "";
        //OutputTextEncoding
        if (this.ReadSubKey(rkSubkey, "OutputTextEncoding", out value))
            cPrintSettings.OutputTextEncoding = value;
        else
            cPrintSettings.OutputTextEncoding = "";
        if (rkSubkey != null) rkSubkey.Close();

        return true;
    }

    /// <summary>
    /// Funkcija cita vrijednost parametra u registry
    /// </summary>
    /// <param name="regLocation">postavljen path do parametra</param>
    /// <param name="regKeyName">parametar name</param>
    /// <param name="value">OUT - procitana vrijednost</param>
    /// <returns>true - parametar postoji|false - parmetar ne postoji</returns>
    private bool ReadSubKey(RegistryKey regLocation, string regKeyName, out string value)
    {
        bool bSuccess = true;
        try
        {
            value = regLocation.GetValue(regKeyName).ToString();
        }
        catch
        {
            value = "";
            bSuccess = false;
            //EventLog.WriteEntry(this._ApplicationName, "Error Reading RegistryKey: " + regLocation.Name + @"\" + regKeyName, EventLogEntryType.Error);
        }
        return bSuccess;
    }


    //private bool GetRegistryKey(RegistryKey baseKey, string registryPath, out RegistryKey regKey)
    //{
    //    bool bSuccess = true;
    //    string [] keys = registryPath. 

    //}

}
