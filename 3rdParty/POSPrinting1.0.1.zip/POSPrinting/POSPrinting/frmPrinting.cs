﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace POSPrinting
{
    public partial class frmPrinting : Form
    {
        private int counter;
        public frmPrinting()
        {
            InitializeComponent();
            counter = 0;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (txtPrint.TextLength > 0)
            {
                PrintDocument p = new PrintDocument();
                string printerName = this.ChoosePrinter();
                if (printerName.Length > 0)
                    p.PrinterSettings.PrinterName = printerName;

                System.Windows.Forms.PrintDialog dlg = new PrintDialog();
                dlg.PrinterSettings.PrinterName = "Neki printer";
                if (dlg.PrinterSettings.IsValid)
                    MessageBox.Show("Printer Exist: " + dlg.PrinterSettings.PrinterName);
                else
                    MessageBox.Show("Printer Does Not Exist");

                System.Drawing.Image imageHeader;
                imageHeader = Image.FromFile(@"E:\POSPrinting\POSPrinting\SHOE-icon.png");
                string fileLocation = @"C:\opt\fiskalk\ispMali.txt";
                // Example #1 
                // Read the file as one string.
                int PictureHeigh = 100;
                Size size = new System.Drawing.Size(200, PictureHeigh);
                imageHeader = this.resizeImage(imageHeader, size);
                PictureHeigh = imageHeader.Height;
                string text = System.IO.File.ReadAllText(fileLocation, Encoding.UTF8);
                txtPrint.Text = text;

                //"Andale Mono", "Courier New"
                Point loc = new Point(0, 0);
                p.PrintPage += delegate(object sender1, PrintPageEventArgs e1)
                {
                    //if (counter == 0)
                    //{
                        e1.Graphics.DrawImage(imageHeader, loc);
                    //    e1.HasMorePages = true;
                    //    counter = 1;
                    //}
                    //else
                    //{
                        e1.Graphics.DrawString(txtPrint.Text, new Font("Consolas", 8), new SolidBrush(Color.Black), new RectangleF(0, PictureHeigh, p.DefaultPageSettings.PrintableArea.Width, p.DefaultPageSettings.PrintableArea.Height));
                    //    e1.HasMorePages = false;
                    //    counter = 0;
                    //}
                };
                try
                {
                    p.Print();
                }
                catch (Exception ex)
                {
                    throw new Exception("Exception Occured While Printing", ex);
                }
            }
        }

        private void btnLoadRacun_Click(object sender, EventArgs e)
        {
            string fileLocation = @"C:\opt\fiskalk\ispMali.txt";
            Encoding ec = Encoding.GetEncoding(1250);
            // Example #1 
            // Read the file as one string. 
            //string text = System.IO.File.ReadAllText(fileLocation, Encoding.Default);
            string text = System.IO.File.ReadAllText(fileLocation, ec);
            txtPrint.Text = text;
        }

        private void btnWriteRacun_Click(object sender, EventArgs e)
        {
            string fileLocation = @"C:\opt\fiskalk\ispMali.txt";
            Encoding ec = Encoding.GetEncoding(852);
            // Example #1 
            // Read the file as one string. 
            System.IO.File.WriteAllText(fileLocation, txtPrint.Text, Encoding.UTF8);
        }

        private string ChoosePrinter()
        {
            PrintDialog printDialog = new PrintDialog();
            printDialog.AllowCurrentPage = false;
            printDialog.AllowPrintToFile = false;
            printDialog.AllowSelection = false;
            printDialog.AllowSomePages = false;

            string choosedPrinterName = "";
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                choosedPrinterName = printDialog.PrinterSettings.PrinterName;
                //printDocument.PrinterSettings.Copies = printDialog.PrinterSettings.Copies;
            }
            return choosedPrinterName;
        }

        private Image resizeImage(Image imgToResize, Size size)
        {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;

            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;

            nPercentW = ((float)size.Width / (float)sourceWidth);
            nPercentH = ((float)size.Height / (float)sourceHeight);

            if (nPercentH < nPercentW)
                nPercent = nPercentH;
            else
                nPercent = nPercentW;

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((Image)b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();

            return (Image)b;
        }
    }
}
