﻿namespace POSPrinting
{
    partial class frmPostavke
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbFileData = new System.Windows.Forms.GroupBox();
            this.lblEncodingIN = new System.Windows.Forms.Label();
            this.txtEncIN = new System.Windows.Forms.TextBox();
            this.btnChooseTxtFile = new System.Windows.Forms.Button();
            this.txtTextFilePath = new System.Windows.Forms.TextBox();
            this.btnLoadRacun = new System.Windows.Forms.Button();
            this.txtPrint = new System.Windows.Forms.TextBox();
            this.btnSpremiSve = new System.Windows.Forms.Button();
            this.chkPrintFile = new System.Windows.Forms.CheckBox();
            this.btnChoosePrinter = new System.Windows.Forms.Button();
            this.txtPrinterName = new System.Windows.Forms.TextBox();
            this.lblPrinter = new System.Windows.Forms.Label();
            this.chkConvertFileEnc = new System.Windows.Forms.CheckBox();
            this.lblEncodingOUT = new System.Windows.Forms.Label();
            this.txtEncOUT = new System.Windows.Forms.TextBox();
            this.gbSlikaHeadera = new System.Windows.Forms.GroupBox();
            this.btnUcitajHeaderImage = new System.Windows.Forms.Button();
            this.pbHeaderImage = new System.Windows.Forms.PictureBox();
            this.lblSirina = new System.Windows.Forms.Label();
            this.txtImageSirina = new System.Windows.Forms.TextBox();
            this.lblVisina = new System.Windows.Forms.Label();
            this.txtImageVisina = new System.Windows.Forms.TextBox();
            this.chkSlikaIspis = new System.Windows.Forms.CheckBox();
            this.btnChooseImage = new System.Windows.Forms.Button();
            this.txtImageFilePath = new System.Windows.Forms.TextBox();
            this.btnPrintFont = new System.Windows.Forms.Button();
            this.gbFileData.SuspendLayout();
            this.gbSlikaHeadera.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeaderImage)).BeginInit();
            this.SuspendLayout();
            // 
            // gbFileData
            // 
            this.gbFileData.Controls.Add(this.lblEncodingIN);
            this.gbFileData.Controls.Add(this.txtEncIN);
            this.gbFileData.Controls.Add(this.btnChooseTxtFile);
            this.gbFileData.Controls.Add(this.txtTextFilePath);
            this.gbFileData.Controls.Add(this.btnLoadRacun);
            this.gbFileData.Controls.Add(this.txtPrint);
            this.gbFileData.Location = new System.Drawing.Point(6, 100);
            this.gbFileData.Name = "gbFileData";
            this.gbFileData.Size = new System.Drawing.Size(245, 351);
            this.gbFileData.TabIndex = 0;
            this.gbFileData.TabStop = false;
            this.gbFileData.Text = "Ulazna datoteka";
            // 
            // lblEncodingIN
            // 
            this.lblEncodingIN.AutoSize = true;
            this.lblEncodingIN.Location = new System.Drawing.Point(7, 51);
            this.lblEncodingIN.Name = "lblEncodingIN";
            this.lblEncodingIN.Size = new System.Drawing.Size(100, 13);
            this.lblEncodingIN.TabIndex = 7;
            this.lblEncodingIN.Text = "Encoding datoteke:";
            // 
            // txtEncIN
            // 
            this.txtEncIN.Location = new System.Drawing.Point(113, 48);
            this.txtEncIN.Name = "txtEncIN";
            this.txtEncIN.Size = new System.Drawing.Size(42, 20);
            this.txtEncIN.TabIndex = 6;
            // 
            // btnChooseTxtFile
            // 
            this.btnChooseTxtFile.Location = new System.Drawing.Point(212, 18);
            this.btnChooseTxtFile.Name = "btnChooseTxtFile";
            this.btnChooseTxtFile.Size = new System.Drawing.Size(27, 21);
            this.btnChooseTxtFile.TabIndex = 5;
            this.btnChooseTxtFile.Text = "V";
            this.btnChooseTxtFile.UseVisualStyleBackColor = true;
            this.btnChooseTxtFile.Click += new System.EventHandler(this.btnChooseTxtFile_Click);
            // 
            // txtTextFilePath
            // 
            this.txtTextFilePath.Enabled = false;
            this.txtTextFilePath.Location = new System.Drawing.Point(10, 19);
            this.txtTextFilePath.Name = "txtTextFilePath";
            this.txtTextFilePath.Size = new System.Drawing.Size(196, 20);
            this.txtTextFilePath.TabIndex = 4;
            // 
            // btnLoadRacun
            // 
            this.btnLoadRacun.Location = new System.Drawing.Point(173, 46);
            this.btnLoadRacun.Name = "btnLoadRacun";
            this.btnLoadRacun.Size = new System.Drawing.Size(66, 23);
            this.btnLoadRacun.TabIndex = 3;
            this.btnLoadRacun.Text = "Učitaj";
            this.btnLoadRacun.UseVisualStyleBackColor = true;
            this.btnLoadRacun.Click += new System.EventHandler(this.btnLoadRacun_Click);
            // 
            // txtPrint
            // 
            this.txtPrint.Location = new System.Drawing.Point(6, 75);
            this.txtPrint.Multiline = true;
            this.txtPrint.Name = "txtPrint";
            this.txtPrint.Size = new System.Drawing.Size(233, 270);
            this.txtPrint.TabIndex = 1;
            // 
            // btnSpremiSve
            // 
            this.btnSpremiSve.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSpremiSve.Location = new System.Drawing.Point(399, 59);
            this.btnSpremiSve.Name = "btnSpremiSve";
            this.btnSpremiSve.Size = new System.Drawing.Size(108, 40);
            this.btnSpremiSve.TabIndex = 4;
            this.btnSpremiSve.Text = "Spremi sve postavke";
            this.btnSpremiSve.UseVisualStyleBackColor = true;
            this.btnSpremiSve.Click += new System.EventHandler(this.btnSpremiSve_Click);
            // 
            // chkPrintFile
            // 
            this.chkPrintFile.AutoSize = true;
            this.chkPrintFile.Location = new System.Drawing.Point(6, 12);
            this.chkPrintFile.Name = "chkPrintFile";
            this.chkPrintFile.Size = new System.Drawing.Size(92, 17);
            this.chkPrintFile.TabIndex = 5;
            this.chkPrintFile.Text = "Ispis datoteke";
            this.chkPrintFile.UseVisualStyleBackColor = true;
            this.chkPrintFile.CheckedChanged += new System.EventHandler(this.chkPrintFile_CheckedChanged);
            // 
            // btnChoosePrinter
            // 
            this.btnChoosePrinter.Location = new System.Drawing.Point(365, 8);
            this.btnChoosePrinter.Name = "btnChoosePrinter";
            this.btnChoosePrinter.Size = new System.Drawing.Size(27, 21);
            this.btnChoosePrinter.TabIndex = 7;
            this.btnChoosePrinter.Text = "V";
            this.btnChoosePrinter.UseVisualStyleBackColor = true;
            this.btnChoosePrinter.Click += new System.EventHandler(this.btnChoosePrinter_Click);
            // 
            // txtPrinterName
            // 
            this.txtPrinterName.Enabled = false;
            this.txtPrinterName.Location = new System.Drawing.Point(163, 9);
            this.txtPrinterName.Name = "txtPrinterName";
            this.txtPrinterName.Size = new System.Drawing.Size(196, 20);
            this.txtPrinterName.TabIndex = 6;
            // 
            // lblPrinter
            // 
            this.lblPrinter.AutoSize = true;
            this.lblPrinter.Location = new System.Drawing.Point(123, 12);
            this.lblPrinter.Name = "lblPrinter";
            this.lblPrinter.Size = new System.Drawing.Size(40, 13);
            this.lblPrinter.TabIndex = 8;
            this.lblPrinter.Text = "Printer:";
            // 
            // chkConvertFileEnc
            // 
            this.chkConvertFileEnc.AutoSize = true;
            this.chkConvertFileEnc.Location = new System.Drawing.Point(6, 52);
            this.chkConvertFileEnc.Name = "chkConvertFileEnc";
            this.chkConvertFileEnc.Size = new System.Drawing.Size(128, 17);
            this.chkConvertFileEnc.TabIndex = 9;
            this.chkConvertFileEnc.Text = "Konverzija encodinga";
            this.chkConvertFileEnc.UseVisualStyleBackColor = true;
            this.chkConvertFileEnc.CheckedChanged += new System.EventHandler(this.chkConvertFileEnc_CheckedChanged);
            // 
            // lblEncodingOUT
            // 
            this.lblEncodingOUT.AutoSize = true;
            this.lblEncodingOUT.Location = new System.Drawing.Point(159, 52);
            this.lblEncodingOUT.Name = "lblEncodingOUT";
            this.lblEncodingOUT.Size = new System.Drawing.Size(86, 13);
            this.lblEncodingOUT.TabIndex = 11;
            this.lblEncodingOUT.Text = "Izlazni encoding:";
            // 
            // txtEncOUT
            // 
            this.txtEncOUT.Location = new System.Drawing.Point(251, 50);
            this.txtEncOUT.Name = "txtEncOUT";
            this.txtEncOUT.Size = new System.Drawing.Size(40, 20);
            this.txtEncOUT.TabIndex = 10;
            // 
            // gbSlikaHeadera
            // 
            this.gbSlikaHeadera.Controls.Add(this.btnUcitajHeaderImage);
            this.gbSlikaHeadera.Controls.Add(this.pbHeaderImage);
            this.gbSlikaHeadera.Controls.Add(this.lblSirina);
            this.gbSlikaHeadera.Controls.Add(this.txtImageSirina);
            this.gbSlikaHeadera.Controls.Add(this.lblVisina);
            this.gbSlikaHeadera.Controls.Add(this.txtImageVisina);
            this.gbSlikaHeadera.Controls.Add(this.chkSlikaIspis);
            this.gbSlikaHeadera.Controls.Add(this.btnChooseImage);
            this.gbSlikaHeadera.Controls.Add(this.txtImageFilePath);
            this.gbSlikaHeadera.Location = new System.Drawing.Point(259, 100);
            this.gbSlikaHeadera.Name = "gbSlikaHeadera";
            this.gbSlikaHeadera.Size = new System.Drawing.Size(248, 351);
            this.gbSlikaHeadera.TabIndex = 12;
            this.gbSlikaHeadera.TabStop = false;
            this.gbSlikaHeadera.Text = "Slika headera";
            // 
            // btnUcitajHeaderImage
            // 
            this.btnUcitajHeaderImage.Location = new System.Drawing.Point(176, 79);
            this.btnUcitajHeaderImage.Name = "btnUcitajHeaderImage";
            this.btnUcitajHeaderImage.Size = new System.Drawing.Size(66, 23);
            this.btnUcitajHeaderImage.TabIndex = 17;
            this.btnUcitajHeaderImage.Text = "Učitaj";
            this.btnUcitajHeaderImage.UseVisualStyleBackColor = true;
            this.btnUcitajHeaderImage.Click += new System.EventHandler(this.btnUcitajHeaderImage_Click);
            // 
            // pbHeaderImage
            // 
            this.pbHeaderImage.Location = new System.Drawing.Point(6, 114);
            this.pbHeaderImage.Name = "pbHeaderImage";
            this.pbHeaderImage.Size = new System.Drawing.Size(236, 231);
            this.pbHeaderImage.TabIndex = 16;
            this.pbHeaderImage.TabStop = false;
            // 
            // lblSirina
            // 
            this.lblSirina.AutoSize = true;
            this.lblSirina.Location = new System.Drawing.Point(96, 85);
            this.lblSirina.Name = "lblSirina";
            this.lblSirina.Size = new System.Drawing.Size(36, 13);
            this.lblSirina.TabIndex = 15;
            this.lblSirina.Text = "Širina:";
            // 
            // txtImageSirina
            // 
            this.txtImageSirina.Location = new System.Drawing.Point(135, 82);
            this.txtImageSirina.Name = "txtImageSirina";
            this.txtImageSirina.Size = new System.Drawing.Size(40, 20);
            this.txtImageSirina.TabIndex = 14;
            // 
            // lblVisina
            // 
            this.lblVisina.AutoSize = true;
            this.lblVisina.Location = new System.Drawing.Point(8, 85);
            this.lblVisina.Name = "lblVisina";
            this.lblVisina.Size = new System.Drawing.Size(38, 13);
            this.lblVisina.TabIndex = 13;
            this.lblVisina.Text = "Visina:";
            // 
            // txtImageVisina
            // 
            this.txtImageVisina.Location = new System.Drawing.Point(47, 82);
            this.txtImageVisina.Name = "txtImageVisina";
            this.txtImageVisina.Size = new System.Drawing.Size(40, 20);
            this.txtImageVisina.TabIndex = 12;
            // 
            // chkSlikaIspis
            // 
            this.chkSlikaIspis.AutoSize = true;
            this.chkSlikaIspis.Location = new System.Drawing.Point(8, 23);
            this.chkSlikaIspis.Name = "chkSlikaIspis";
            this.chkSlikaIspis.Size = new System.Drawing.Size(71, 17);
            this.chkSlikaIspis.TabIndex = 8;
            this.chkSlikaIspis.Text = "Ispis slike";
            this.chkSlikaIspis.UseVisualStyleBackColor = true;
            this.chkSlikaIspis.CheckedChanged += new System.EventHandler(this.chkSlikaIspis_CheckedChanged);
            // 
            // btnChooseImage
            // 
            this.btnChooseImage.Location = new System.Drawing.Point(215, 47);
            this.btnChooseImage.Name = "btnChooseImage";
            this.btnChooseImage.Size = new System.Drawing.Size(27, 21);
            this.btnChooseImage.TabIndex = 7;
            this.btnChooseImage.Text = "V";
            this.btnChooseImage.UseVisualStyleBackColor = true;
            this.btnChooseImage.Click += new System.EventHandler(this.btnChooseImage_Click);
            // 
            // txtImageFilePath
            // 
            this.txtImageFilePath.Enabled = false;
            this.txtImageFilePath.Location = new System.Drawing.Point(6, 49);
            this.txtImageFilePath.Name = "txtImageFilePath";
            this.txtImageFilePath.Size = new System.Drawing.Size(196, 20);
            this.txtImageFilePath.TabIndex = 6;
            // 
            // btnPrintFont
            // 
            this.btnPrintFont.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnPrintFont.Location = new System.Drawing.Point(398, 8);
            this.btnPrintFont.Name = "btnPrintFont";
            this.btnPrintFont.Size = new System.Drawing.Size(108, 40);
            this.btnPrintFont.TabIndex = 13;
            this.btnPrintFont.Text = "FONT:";
            this.btnPrintFont.UseVisualStyleBackColor = true;
            this.btnPrintFont.Click += new System.EventHandler(this.btnPrintFont_Click);
            // 
            // frmPostavke
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 458);
            this.Controls.Add(this.btnPrintFont);
            this.Controls.Add(this.gbSlikaHeadera);
            this.Controls.Add(this.lblEncodingOUT);
            this.Controls.Add(this.txtEncOUT);
            this.Controls.Add(this.chkConvertFileEnc);
            this.Controls.Add(this.lblPrinter);
            this.Controls.Add(this.btnChoosePrinter);
            this.Controls.Add(this.txtPrinterName);
            this.Controls.Add(this.chkPrintFile);
            this.Controls.Add(this.btnSpremiSve);
            this.Controls.Add(this.gbFileData);
            this.Name = "frmPostavke";
            this.Text = "frmPostavke";
            this.gbFileData.ResumeLayout(false);
            this.gbFileData.PerformLayout();
            this.gbSlikaHeadera.ResumeLayout(false);
            this.gbSlikaHeadera.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeaderImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbFileData;
        private System.Windows.Forms.TextBox txtPrint;
        private System.Windows.Forms.Label lblEncodingIN;
        private System.Windows.Forms.TextBox txtEncIN;
        private System.Windows.Forms.Button btnChooseTxtFile;
        private System.Windows.Forms.TextBox txtTextFilePath;
        private System.Windows.Forms.Button btnLoadRacun;
        private System.Windows.Forms.Button btnSpremiSve;
        private System.Windows.Forms.CheckBox chkPrintFile;
        private System.Windows.Forms.Button btnChoosePrinter;
        private System.Windows.Forms.TextBox txtPrinterName;
        private System.Windows.Forms.Label lblPrinter;
        private System.Windows.Forms.CheckBox chkConvertFileEnc;
        private System.Windows.Forms.Label lblEncodingOUT;
        private System.Windows.Forms.TextBox txtEncOUT;
        private System.Windows.Forms.GroupBox gbSlikaHeadera;
        private System.Windows.Forms.CheckBox chkSlikaIspis;
        private System.Windows.Forms.Button btnChooseImage;
        private System.Windows.Forms.TextBox txtImageFilePath;
        private System.Windows.Forms.Button btnUcitajHeaderImage;
        private System.Windows.Forms.PictureBox pbHeaderImage;
        private System.Windows.Forms.Label lblSirina;
        private System.Windows.Forms.TextBox txtImageSirina;
        private System.Windows.Forms.Label lblVisina;
        private System.Windows.Forms.TextBox txtImageVisina;
        private System.Windows.Forms.Button btnPrintFont;
    }
}