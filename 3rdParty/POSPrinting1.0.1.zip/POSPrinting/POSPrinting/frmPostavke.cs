﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace POSPrinting
{
    public partial class frmPostavke : Form
    {
        private clsPrintSettings cPrintSettings;
        RegistryHandler registryHandler = new RegistryHandler("POSPrinting", @"SOFTWARE\Juka-NET\POSPrinting\");

        public frmPostavke(clsPrintSettings cInitialPrintSettings)
        {
            InitializeComponent();
            cPrintSettings = cInitialPrintSettings;
            txtTextFilePath.Text = cPrintSettings.TextFilePath;
            txtEncIN.Text = cPrintSettings.InputTextEncoding;

            chkPrintFile.Checked = cPrintSettings.bPrintFileToPrinter;
            txtPrinterName.Text = cPrintSettings.PrinterName;

            chkConvertFileEnc.Checked = cPrintSettings.bChangeAndRewriteFileEncoding;
            txtEncOUT.Text = cPrintSettings.OutputTextEncoding;

            chkSlikaIspis.Checked = cPrintSettings.bHeaderImageIsPrinting;
            txtImageFilePath.Text = cPrintSettings.HeaderImageFilePath;
            txtImageSirina.Text = cPrintSettings.HeaderImagePrintingWidth.ToString();
            txtImageVisina.Text = cPrintSettings.HeaderImagePrintingHeight.ToString();

            btnPrintFont.Font = cPrintSettings.PrintFont;

            this.PostaviFormu();
        }


        private void PostaviFormu()
        {
            lblPrinter.Enabled = chkPrintFile.Checked;
            //txtPrinterName.Enabled = chkPrintFile.Checked;
            btnChoosePrinter.Enabled = chkPrintFile.Checked;

            lblEncodingOUT.Enabled = chkConvertFileEnc.Checked;
            txtEncOUT.Enabled = chkConvertFileEnc.Checked;

            lblSirina.Enabled = chkSlikaIspis.Checked;
            lblVisina.Enabled = chkSlikaIspis.Checked;
            txtImageSirina.Enabled = chkSlikaIspis.Checked;
            txtImageVisina.Enabled = chkSlikaIspis.Checked;
            //txtImageFilePath.Enabled = chkSlikaIspis.Checked;
            btnChooseImage.Enabled = chkSlikaIspis.Checked;

            txtPrint.Font = btnPrintFont.Font;
        }

        private void btnChooseTxtFile_Click(object sender, EventArgs e)
        {
            //System.IO.
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckPathExists = true;
            openFileDialog.CheckFileExists = true;
            if (txtTextFilePath.TextLength > 0)
            {
                if (File.Exists(txtTextFilePath.Text))
                {
                    openFileDialog.InitialDirectory = Path.GetDirectoryName(txtTextFilePath.Text);
                    openFileDialog.FileName = Path.GetFileName(txtTextFilePath.Text);
                }
            }

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txtTextFilePath.Text = openFileDialog.FileName;
            }
        }

        private void btnLoadRacun_Click(object sender, EventArgs e)
        {
            try
            {
                string fileLocation = txtTextFilePath.Text;
                Encoding ec = Encoding.GetEncoding(1250);
                // Example #1 
                // Read the file as one string. 
                //string text = System.IO.File.ReadAllText(fileLocation, Encoding.Default);
                string text = System.IO.File.ReadAllText(fileLocation, ec);
                txtPrint.Text = text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Greška pri čitanju datoteke!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnSpremiSve_Click(object sender, EventArgs e)
        {
            cPrintSettings.TextFilePath = txtTextFilePath.Text.Trim();
            cPrintSettings.InputTextEncoding = txtEncIN.Text.Trim();
            cPrintSettings.bPrintFileToPrinter = chkPrintFile.Checked;
            cPrintSettings.bChangeAndRewriteFileEncoding = chkConvertFileEnc.Checked;
            cPrintSettings.OutputTextEncoding = txtEncOUT.Text.Trim();
            cPrintSettings.PrinterName = txtPrinterName.Text.Trim();

            cPrintSettings.bHeaderImageIsPrinting = chkSlikaIspis.Checked;
            cPrintSettings.HeaderImageFilePath = txtImageFilePath.Text;

            int nValue;
            int visina, sirina;
            if (int.TryParse(txtImageVisina.Text, out nValue))
                cPrintSettings.HeaderImagePrintingHeight = nValue;
            else
            {
                cPrintSettings.HeaderImagePrintingHeight = 100;
                txtImageVisina.Text = "100";
            }
            if (int.TryParse(txtImageSirina.Text, out nValue))
                cPrintSettings.HeaderImagePrintingWidth = nValue;
            else
            {
                cPrintSettings.HeaderImagePrintingWidth = 100;
                txtImageSirina.Text = "100";
            }

            cPrintSettings.PrintFont = btnPrintFont.Font;

            string errorMessage;
            if (cPrintSettings.IsDataValid(out errorMessage))
            {
                registryHandler.WritePrinterSettings(cPrintSettings);
                this.Close();
            }
            else
            {
                MessageBox.Show("Unesene postavke nisu ispravne: " + errorMessage, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkPrintFile_CheckedChanged(object sender, EventArgs e)
        {
            this.PostaviFormu();
        }

        private void chkConvertFileEnc_CheckedChanged(object sender, EventArgs e)
        {
            this.PostaviFormu();
        }

        private void chkSlikaIspis_CheckedChanged(object sender, EventArgs e)
        {
            this.PostaviFormu();
        }

        private void btnChoosePrinter_Click(object sender, EventArgs e)
        {
            string printerName = txtPrinterName.Text.Trim();
            txtPrinterName.Text = this.ChoosePrinter(printerName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private string ChoosePrinter(string PrinterName)
        {
            PrintDialog printDialog = new PrintDialog();
            printDialog.AllowCurrentPage = false;
            printDialog.AllowPrintToFile = false;
            printDialog.AllowSelection = false;
            printDialog.AllowSomePages = false;

            if (PrinterName.Trim().Length > 0)
                printDialog.PrinterSettings.PrinterName = PrinterName;

            string choosedPrinterName = PrinterName;
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                choosedPrinterName = printDialog.PrinterSettings.PrinterName;
                //printDocument.PrinterSettings.Copies = printDialog.PrinterSettings.Copies;
            }
            return choosedPrinterName;
        }

        private void btnChooseImage_Click(object sender, EventArgs e)
        {
            //System.IO.
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckPathExists = true;
            openFileDialog.CheckFileExists = true;
            if (txtImageFilePath.TextLength > 0)
            {
                if (File.Exists(txtImageFilePath.Text))
                {
                    openFileDialog.InitialDirectory = Path.GetDirectoryName(txtImageFilePath.Text);
                    openFileDialog.FileName = Path.GetFileName(txtImageFilePath.Text);
                }
            }

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txtImageFilePath.Text = openFileDialog.FileName;
            }
        }

        private void btnUcitajHeaderImage_Click(object sender, EventArgs e)
        {
            int nValue;
            int visina, sirina;
            if (int.TryParse(txtImageVisina.Text, out nValue))
                visina = nValue;
            else
            {
                visina = 100;
                txtImageVisina.Text = "100";
            }
            if (int.TryParse(txtImageSirina.Text, out nValue))
                sirina = nValue;
            else
            {
                sirina = 100;
                txtImageSirina.Text = "100";
            }

            try
            {
                string fileLocation = txtImageFilePath.Text;
                System.Drawing.Image imageHeader;
                imageHeader = Image.FromFile(@fileLocation);
                Size size = new System.Drawing.Size(sirina, visina);

                imageHeader = this.resizeImage(imageHeader, size);
                if (imageHeader.Height != visina)
                {
                    visina = imageHeader.Height;
                    txtImageVisina.Text = visina.ToString();
                }
                if (imageHeader.Width != sirina)
                {
                    sirina = imageHeader.Width;
                    txtImageSirina.Text = sirina.ToString();
                }

                //pbHeaderImage.SizeMode = PictureBoxSizeMode.AutoSize;
                pbHeaderImage.Image = imageHeader;
                //pbHeaderImage.Location = new Point(-100, -100);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Greška pri čitanju datoteke!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Image resizeImage(Image imgToResize, Size size)
        {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;

            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;

            nPercentW = ((float)size.Width / (float)sourceWidth);
            nPercentH = ((float)size.Height / (float)sourceHeight);

            if (nPercentH < nPercentW)
                nPercent = nPercentH;
            else
                nPercent = nPercentW;

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((Image)b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();

            return (Image)b;
        }

        private void btnPrintFont_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.AllowVerticalFonts = false;
            fontDialog.FixedPitchOnly = true;
            fontDialog.Font = btnPrintFont.Font;

            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                btnPrintFont.Font = fontDialog.Font;
                this.PostaviFormu();
            }
        }


    }
}
