﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace POSPrinting
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            clsPrintSettings cPrintSettings;
            RegistryHandler registryHandler = new RegistryHandler("POSPrinting", @"SOFTWARE\Juka-NET\POSPrinting\");
            registryHandler.ReadData(out cPrintSettings);
            
            string errorMessage;
            string odabranaDatotekaZaIspisPath = "";
            bool bIspisSpecificneDatoteke = false;
            bool bContinueWithPrint = true;

            if (args.Length > 0)
            {
                if (args[0].Length < 2)
                {
                    bContinueWithPrint = false;
                    MessageBox.Show("-p za promjene postavki. \n-fFilePath za ispis specifične datoteke!!!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    switch (args[0].Substring(0, 2))
                    {
                        case "-p":
                            //postavke programa
                            bContinueWithPrint = false;
                            frmPostavke fPostavke = new frmPostavke(cPrintSettings);
                            fPostavke.ShowDialog();
                            registryHandler.ReadData(out cPrintSettings);

                            if (!cPrintSettings.IsDataValid(out errorMessage))
                            {
                                MessageBox.Show("Unesene postavke nisu ispravne: " + errorMessage, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            break;
                        case "-f":
                            //ispis datoteke
                            bContinueWithPrint = true;
                            bIspisSpecificneDatoteke = true;
                            if (args[0].Length < 3)
                            {
                                bContinueWithPrint = false;
                                MessageBox.Show("-p za promjene postavki. \n-fFilePath za ispis specifične datoteke!!!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                odabranaDatotekaZaIspisPath = @args[0].Substring(2, args[0].Length - 2);
                                if (!System.IO.File.Exists(odabranaDatotekaZaIspisPath))
                                {
                                    bContinueWithPrint = false;
                                    MessageBox.Show("Datoteka " + odabranaDatotekaZaIspisPath + " ne postoji!!!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                            break;
                        default:
                            bContinueWithPrint = false;
                            MessageBox.Show("-p za promjene postavki. \n-fFilePath za ispis specifične datoteke!!!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                    }
                }
                if (!bContinueWithPrint)
                    return;
            }

            bool bKraj = false;

            // postaviti file za ispis
            if (bIspisSpecificneDatoteke && !bKraj)
            {
                cPrintSettings.TextFilePath = odabranaDatotekaZaIspisPath;
            }

            // provjera postavki
            while (!cPrintSettings.IsDataValid(out errorMessage) && !bKraj)
            {
                bKraj = MessageBox.Show("Postavke ispisa nisu ispravne.\n" + errorMessage + "\nŽelite li podesiti postavke?", "Izbor", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No;
                if (!bKraj)
                {
                    frmPostavke fPostavke = new frmPostavke(cPrintSettings);
                    fPostavke.ShowDialog();
                    registryHandler.ReadData(out cPrintSettings);
                }
            }

            if (!bKraj)
            {
                //Application.Run(new frmPrinting());
                clsDoJob cDoJob = new clsDoJob(cPrintSettings);
                cDoJob.Run();
            }
        }
    }
}
