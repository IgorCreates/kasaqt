﻿namespace POSPrinting
{
    partial class frmPrinting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPrint = new System.Windows.Forms.TextBox();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnLoadRacun = new System.Windows.Forms.Button();
            this.btnWriteRacun = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPrint
            // 
            this.txtPrint.Location = new System.Drawing.Point(12, 12);
            this.txtPrint.Multiline = true;
            this.txtPrint.Name = "txtPrint";
            this.txtPrint.Size = new System.Drawing.Size(299, 193);
            this.txtPrint.TabIndex = 0;
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(12, 261);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(298, 63);
            this.btnPrint.TabIndex = 1;
            this.btnPrint.Text = "Ispis";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnLoadRacun
            // 
            this.btnLoadRacun.Location = new System.Drawing.Point(12, 213);
            this.btnLoadRacun.Name = "btnLoadRacun";
            this.btnLoadRacun.Size = new System.Drawing.Size(135, 42);
            this.btnLoadRacun.TabIndex = 2;
            this.btnLoadRacun.Text = "Load račun";
            this.btnLoadRacun.UseVisualStyleBackColor = true;
            this.btnLoadRacun.Click += new System.EventHandler(this.btnLoadRacun_Click);
            // 
            // btnWriteRacun
            // 
            this.btnWriteRacun.Location = new System.Drawing.Point(175, 213);
            this.btnWriteRacun.Name = "btnWriteRacun";
            this.btnWriteRacun.Size = new System.Drawing.Size(135, 42);
            this.btnWriteRacun.TabIndex = 3;
            this.btnWriteRacun.Text = "Write račun";
            this.btnWriteRacun.UseVisualStyleBackColor = true;
            this.btnWriteRacun.Click += new System.EventHandler(this.btnWriteRacun_Click);
            // 
            // frmPrinting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 340);
            this.Controls.Add(this.btnWriteRacun);
            this.Controls.Add(this.btnLoadRacun);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.txtPrint);
            this.Name = "frmPrinting";
            this.Text = "Printing example";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPrint;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnLoadRacun;
        private System.Windows.Forms.Button btnWriteRacun;
    }
}

